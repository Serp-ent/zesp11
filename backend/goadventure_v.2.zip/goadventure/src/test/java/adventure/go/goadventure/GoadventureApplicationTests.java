package adventure.go.goadventure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoadventureApplicationTests {

	@Test
	void contextLoads() {
	}

}
